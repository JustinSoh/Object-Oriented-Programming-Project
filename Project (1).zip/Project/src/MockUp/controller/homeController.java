package MockUp.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXHamburger;
import com.jfoenix.transitions.hamburger.*;
public class homeController implements Initializable{
	@FXML
	private JFXHamburger btnHamburg;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		HamburgerSlideCloseTransition transition = new HamburgerSlideCloseTransition(btnHamburg);
		transition.setRate(-1);
		btnHamburg.addEventHandler(MouseEvent.MOUSE_CLICKED,(e)->{
			transition.setRate(transition.getRate()*-1);
			transition.play();
		});
	}

}
